/**
 * Front-end view script for the Advanced Reviews block.
 * Handles AJAX loading, filtering, sorting, paste-to-upload, and star distribution.
 *
 * @package BeplusAdvancedReviewsForWoocommerce
 */

( function () {
	document.addEventListener( 'DOMContentLoaded', function () {
		const blocks = document.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce[data-product-id]' );

		blocks.forEach( function ( block ) {
			initAdvancedReviews( block );
		} );
	} );

	/**
	 * Initialize the advanced reviews block.
	 *
	 * @param {HTMLElement} block The block container element.
	 */
	function initAdvancedReviews( block ) {
		const productId = parseInt( block.dataset.productId, 10 );
		if ( ! productId ) return;

		let currentPage = 1;
		let currentRating = 0;
		let currentHasImages = false;
		let currentSort = 'newest';
		let totalPages = 1;
		block._bparExcludeIds = [];

		const listContainer = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__list' );
		const loadMoreBtn = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__load-more' );
		const loadMoreWrapper = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__load-more-wrapper' );
		const filterStars = block.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce__filter-star' );
		const filterImagesCheckbox = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__filter-images-input' );
		const sortSelect = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__sort-select' );
		const distributionArea = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__distribution' );

		loadInitialReviews();
		loadDistribution();

		/**
		 * Load initial reviews and star distribution.
		 */
		function loadInitialReviews() {
			currentPage = 1;
			block._bparExcludeIds = [];

			if ( listContainer ) {
				showSkeletonCards();
			}

			fetchReviews().then( function ( data ) {
				if ( data && listContainer ) {
					listContainer.innerHTML = buildReviewList( data.reviews );
					totalPages = data.pages;
					block.dataset.totalPages = data.pages;
					updateLoadMoreButton();
				}
			} );

			block.classList.remove( 'beplus-advanced-reviews-for-woocommerce--loading' );
			block.classList.add( 'beplus-advanced-reviews-for-woocommerce--ready' );
		}

		/**
		 * Show skeleton placeholder cards while loading.
		 */
		function showSkeletonCards() {
			var perPage = parseInt( block.dataset.perPage, 10 ) || 5;
			var skeletonCount = Math.min( perPage, 3 );
			var html = '<div class="beplus-advanced-reviews-for-woocommerce__skeleton">';
			for ( var i = 0; i < skeletonCount; i++ ) {
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-card">';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-avatar"></div>';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-body">';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-line beplus-advanced-reviews-for-woocommerce__skeleton-line--short"></div>';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-line beplus-advanced-reviews-for-woocommerce__skeleton-line--medium"></div>';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__skeleton-line beplus-advanced-reviews-for-woocommerce__skeleton-line--long"></div>';
				html += '</div></div>';
			}
			html += '</div>';
			listContainer.innerHTML = html;
		}

		/**
		 * Fetch star distribution.
		 */
		function loadDistribution() {
			const url = new URL( bparfwData.restUrl + 'reviews/distribution' );
			url.searchParams.set( 'product_id', productId );
			url.searchParams.set( '_t', Date.now() );

			fetch( url.toString(), { cache: 'no-store' } )
				.then( function ( res ) { return res.json(); } )
				.then( function ( data ) {
					if ( distributionArea ) {
						distributionArea.innerHTML = buildDistribution( data );
					}
				} )
				.catch( function () {} );
		}

		/**
		 * Fetch reviews from the REST API.
		 *
		 * @return {Promise<Object>} Review data.
		 */
		function fetchReviews() {
			var url = new URL( bparfwData.restUrl + 'reviews' );
			var perPage = parseInt( block.dataset.perPage, 10 ) || 10;

			url.searchParams.set( 'product_id', productId );
			url.searchParams.set( 'page', currentPage );
			url.searchParams.set( 'per_page', perPage );
			url.searchParams.set( 'sort', currentSort );

			if ( currentRating > 0 ) {
				url.searchParams.set( 'rating', currentRating );
			}

			if ( currentHasImages ) {
				url.searchParams.set( 'has_images', '1' );
			}

			if ( block._bparExcludeIds && block._bparExcludeIds.length > 0 ) {
				url.searchParams.set( 'exclude', block._bparExcludeIds.join( ',' ) );
			}

			url.searchParams.set( '_t', Date.now() );

			return fetch( url.toString(), { cache: 'no-store' } )
				.then( function ( res ) { return res.json(); } )
				.catch( function () { return null; } );
		}

		/**
		 * Build review list HTML.
		 *
		 * @param {Array} reviews Array of review objects.
		 * @return {string} HTML string.
		 */
		function buildReviewList( reviews ) {
			if ( ! reviews || ! reviews.length ) {
				return '<p class="beplus-advanced-reviews-for-woocommerce__no-reviews">' + bparfwData.i18n.noReviews + '</p>';
			}

			var html = '';
			reviews.forEach( function ( review ) {
				html += '<article class="beplus-advanced-reviews-for-woocommerce__review-card">';

				if ( block.dataset.showAvatar !== '0' ) {
					html += '<div class="beplus-advanced-reviews-for-woocommerce__review-avatar">';
					if ( review.avatar ) {
						html += '<img src="' + escAttr( review.avatar ) + '" alt="' + escAttr( review.author ) + '" width="40" height="40" loading="lazy">';
					} else {
						html += '<div class="beplus-advanced-reviews-for-woocommerce__review-avatar--fallback">' + escHtml( ( review.author || '' ).charAt(0).toUpperCase() ) + '</div>';
					}
					html += '</div>';
				}

				html += '<div class="beplus-advanced-reviews-for-woocommerce__review-body">';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__review-header">';
				html += '<span class="beplus-advanced-reviews-for-woocommerce__review-author">' + escHtml( review.author ) + '</span>';
				html += '<span class="beplus-advanced-reviews-for-woocommerce__review-rating">' + renderStars( review.rating ) + '</span>';
				html += '</div>';
				html += '<div class="beplus-advanced-reviews-for-woocommerce__review-content">' + review.content + '</div>';

				if ( block.dataset.showImages !== '0' && review.has_images && review.images.length ) {
					var mediaData = review.images.map( function ( m ) {
						return { url: m.url, thumbnail: m.thumbnail || m.url, mime_type: m.mime_type || '' };
					} );
					html += '<div class="beplus-advanced-reviews-for-woocommerce__review-images" data-review-media="' + escAttr( JSON.stringify( mediaData ) ) + '">';
					review.images.forEach( function ( img, idx ) {
						if ( img.mime_type && img.mime_type.indexOf( 'video/' ) === 0 ) {
							html += '<button type="button" class="beplus-advanced-reviews-for-woocommerce__review-media-btn beplus-advanced-reviews-for-woocommerce__review-media-btn--video" data-media-index="' + idx + '" data-media-type="video" aria-label="' + escAttr( bparfwData.i18n.viewMedia || 'View media' ) + '">';
							html += '<video src="' + escAttr( img.url ) + '" width="80" height="80" class="beplus-advanced-reviews-for-woocommerce__review-video" muted preload="metadata"></video>';
							html += '</button>';
						} else {
							html += '<button type="button" class="beplus-advanced-reviews-for-woocommerce__review-media-btn" data-media-index="' + idx + '" data-media-type="image" aria-label="' + escAttr( bparfwData.i18n.viewMedia || 'View media' ) + '">';
							html += '<img src="' + escAttr( img.thumbnail ) + '" alt="" width="80" height="80" loading="lazy" class="beplus-advanced-reviews-for-woocommerce__review-image-thumb">';
							html += '</button>';
						}
					} );
					html += '</div>';
				}

				html += '<div class="beplus-advanced-reviews-for-woocommerce__review-date">' + escHtml( review.date_human ) + '</div>';
				html += '</div>';
				html += '</article>';
			} );

			return html;
		}

		/**
		 * Escape HTML entities.
		 *
		 * @param {string} str Raw string.
		 * @return {string} Escaped string.
		 */
		function escHtml( str ) {
			var div = document.createElement( 'div' );
			div.appendChild( document.createTextNode( str || '' ) );
			return div.innerHTML;
		}

		/**
		 * Escape attribute value.
		 *
		 * @param {string} str Raw string.
		 * @return {string} Escaped string.
		 */
		function escAttr( str ) {
			return ( str || '' ).replace( /"/g, '&quot;' ).replace( /'/g, '&#39;' );
		}

		/**
		 * Update the Load More button visibility.
		 */
		function updateLoadMoreButton() {
			if ( loadMoreWrapper ) {
				loadMoreWrapper.style.display = currentPage < totalPages ? '' : 'none';
			}
		}

		/**
		 * Load more reviews and append them.
		 */
		function loadMore() {
			currentPage++;
			fetchReviews().then( function ( data ) {
				if ( data && listContainer ) {
					if ( data.reviews && data.reviews.length > 0 ) {
						listContainer.insertAdjacentHTML( 'beforeend', buildReviewList( data.reviews ) );
					}
					totalPages = data.pages;
					block.dataset.totalPages = data.pages;
					updateLoadMoreButton();
				}
			} );
		}

		/**
		 * Apply filter and replace the review list.
		 */
		function applyFilter() {
			currentPage = 1;
			block._bparExcludeIds = [];
			fetchReviews().then( function ( data ) {
				if ( data && listContainer ) {
					listContainer.innerHTML = buildReviewList( data.reviews );
					totalPages = data.pages;
					block.dataset.totalPages = data.pages;
					updateLoadMoreButton();
				}
			} );
		}

		if ( loadMoreBtn ) {
			loadMoreBtn.addEventListener( 'click', loadMore );
		}

		filterStars.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var rating = parseInt( btn.dataset.rating, 10 );
				var isActive = btn.getAttribute( 'aria-pressed' ) === 'true';

				filterStars.forEach( function ( b ) {
					b.setAttribute( 'aria-pressed', 'false' );
					b.classList.remove( 'beplus-advanced-reviews-for-woocommerce__filter-star--active' );
				} );

				if ( isActive ) {
					currentRating = 0;
				} else {
					currentRating = rating;
					btn.setAttribute( 'aria-pressed', 'true' );
					btn.classList.add( 'beplus-advanced-reviews-for-woocommerce__filter-star--active' );
				}

				applyFilter();
			} );
		} );

		if ( filterImagesCheckbox ) {
			filterImagesCheckbox.addEventListener( 'change', function () {
				currentHasImages = filterImagesCheckbox.checked;
				applyFilter();
			} );
		}

		if ( sortSelect ) {
			sortSelect.addEventListener( 'change', function () {
				currentSort = sortSelect.value;
				applyFilter();
			} );
		}

		initReviewForm( block );
		initMediaUpload( block );
		initPasteSupport( block );
		initLightbox( block );
	}

	/**
	 * Initialize the review submission form.
	 *
	 * @param {HTMLElement} block The block container element.
	 */
	function initReviewForm( block ) {
		var form = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__submit-form' );
		if ( ! form ) return;

		var ratingInputs = form.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce__star-input' );
		var starLabels = form.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce__star-label' );

		ratingInputs.forEach( function ( input, index ) {
			input.addEventListener( 'change', function () {
				starLabels.forEach( function ( label, i ) {
					var isActive = i >= starLabels.length - parseInt( input.value );
					label.classList.toggle( 'beplus-advanced-reviews-for-woocommerce__star-label--active', isActive );
				} );
			} );
		} );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();

			var formData = new FormData( form );
			var rating = formData.get( 'rating' );
			var content = formData.get( 'content' );

			if ( ! rating ) {
				showFormMessage( block, bparfwData.i18n.ratingRequired, 'error' );
				return;
			}

			if ( ! content || ! content.trim() ) {
				showFormMessage( block, bparfwData.i18n.contentRequired, 'error' );
				return;
			}

			var data = {
				rating: rating,
				content: content,
				author: formData.get( 'author' ) || '',
				email: formData.get( 'email' ) || '',
			};

			submitReview( block, data, form );
		} );
	}

	/**
	 * Initialize media upload previews and drag/drop.
	 *
	 * @param {HTMLElement} block The block container element.
	 */
	function initMediaUpload( block ) {
		var form = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__submit-form' );
		if ( ! form ) return;

		var previewContainer = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview' );
		var mediaFiles = [];
		block._bparMediaFiles = mediaFiles;

		var uploadZone = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__upload-zone' );
		var fileInput = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__upload-zone-input' );

		if ( fileInput ) {
			fileInput.addEventListener( 'change', function () {
				if ( ! fileInput.files ) return;
				for ( var i = 0; i < fileInput.files.length; i++ ) {
					var file = fileInput.files[ i ];
					var isImage = file.type && file.type.indexOf( 'image/' ) === 0;
					var isVideo = file.type && file.type.indexOf( 'video/' ) === 0;
					
					if ( isImage && ! bparfwData.imagesEnabled ) {
						showFormMessage( block, bparfwData.i18n.imageNotAllowed || 'Image uploads are disabled.', 'error' );
						continue;
					}

					if ( isVideo && ! bparfwData.videosEnabled ) {
						showFormMessage( block, bparfwData.i18n.videoNotAllowed || 'Video uploads are disabled.', 'error' );
						continue;
					}

					if ( isImage || isVideo ) {
						mediaFiles.push( { file: file, removed: false } );
					}
				}
				fileInput.value = '';
				updatePreviews();
			} );
		}

		if ( uploadZone && fileInput ) {
			uploadZone.addEventListener( 'click', function ( e ) {
				if ( e.target === fileInput ) return;
				fileInput.click();
			} );
		}

		if ( uploadZone ) {
			uploadZone.addEventListener( 'dragover', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				uploadZone.classList.add( 'beplus-advanced-reviews-for-woocommerce__upload-zone--dragover' );
			} );

			uploadZone.addEventListener( 'dragleave', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				uploadZone.classList.remove( 'beplus-advanced-reviews-for-woocommerce__upload-zone--dragover' );
			} );

			uploadZone.addEventListener( 'drop', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				uploadZone.classList.remove( 'beplus-advanced-reviews-for-woocommerce__upload-zone--dragover' );

				var files = e.dataTransfer.files;
				if ( ! files || ! files.length ) return;

				for ( var i = 0; i < files.length; i++ ) {
					var file = files[ i ];
					var isImage = file.type && file.type.indexOf( 'image/' ) === 0;
					var isVideo = file.type && file.type.indexOf( 'video/' ) === 0;

					if ( isImage && ! bparfwData.imagesEnabled ) {
						showFormMessage( block, bparfwData.i18n.imageNotAllowed || 'Image uploads are disabled.', 'error' );
						continue;
					}

					if ( isVideo && ! bparfwData.videosEnabled ) {
						showFormMessage( block, bparfwData.i18n.videoNotAllowed || 'Video uploads are disabled.', 'error' );
						continue;
					}

					if ( isImage || isVideo ) {
						mediaFiles.push( { file: file, removed: false } );
					}
				}
				updatePreviews();
			} );
		}

		function removeFile( index ) {
			if ( mediaFiles[ index ] ) {
				mediaFiles[ index ].removed = true;
				updatePreviews();
			}
		}

		function updatePreviews() {
			if ( ! previewContainer ) return;

			var activeFiles = mediaFiles.filter( function ( m ) {
				return ! m.removed;
			} );

			if ( ! activeFiles.length ) {
				previewContainer.style.display = 'none';
				previewContainer.innerHTML = '';
				return;
			}

			previewContainer.style.display = '';
			var html = '';
			var actualIndex = 0;

			mediaFiles.forEach( function ( item, idx ) {
				if ( item.removed ) return;

				var file = item.file;
				var isVideo = file.type && file.type.indexOf( 'video/' ) === 0;
				html += '<div class="beplus-advanced-reviews-for-woocommerce__media-preview-item">';

				if ( isVideo ) {
					var videoUrl = URL.createObjectURL( file );
					html += '<video src="' + videoUrl + '" width="120" height="68" controls class="beplus-advanced-reviews-for-woocommerce__media-preview-video"></video>';
				} else {
					var imgUrl = URL.createObjectURL( file );
					html += '<img src="' + imgUrl + '" alt="' + escapeAttr( file.name ) + '" width="80" height="80" class="beplus-advanced-reviews-for-woocommerce__media-preview-img">';
				}

				html += '<span class="beplus-advanced-reviews-for-woocommerce__media-preview-name">' + escapeHtml( file.name ) + '</span>';
				html += '<button type="button" class="beplus-advanced-reviews-for-woocommerce__media-preview-remove" data-index="' + idx + '" aria-label="Remove">&#10005;</button>';
				html += '</div>';
			} );

			previewContainer.innerHTML = html;

			var removeButtons = previewContainer.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce__media-preview-remove' );
			removeButtons.forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var idx = parseInt( btn.dataset.index, 10 );
					removeFile( idx );
				} );
			} );
		}

		function escapeHtml( str ) {
			var div = document.createElement( 'div' );
			div.appendChild( document.createTextNode( str || '' ) );
			return div.innerHTML;
		}

		function escapeAttr( str ) {
			return ( str || '' ).replace( /"/g, '&quot;' ).replace( /'/g, '&#39;' );
		}
	}

	/**
	 * Submit a review via REST API.
	 *
	 * @param {HTMLElement} block Block container.
	 * @param {Object}      data  Review data.
	 * @param {HTMLFormElement} form The form element.
	 */
	function submitReview( block, data, form ) {
		var productId = parseInt( block.dataset.productId, 10 );
		var formData = new FormData();

		formData.append( 'product_id', productId );
		formData.append( 'rating', data.rating );
		formData.append( 'content', data.content );

		if ( data.author ) {
			formData.append( 'author', data.author );
		}
		if ( data.email ) {
			formData.append( 'email', data.email );
		}

		var mediaFiles = block._bparMediaFiles || [];
		var hasSizeError = false;
		mediaFiles.forEach( function ( item ) {
			if ( item.removed ) return;
			var file = item.file;
			var isVideo = file.type && file.type.indexOf( 'video/' ) === 0;
			var maxSize = isVideo
				? ( bparfwData.maxVideoSize || 20971520 )
				: ( bparfwData.maxUploadSize || 2097152 );
			if ( file.size > maxSize ) {
				showFormMessage( block, isVideo
					? ( bparfwData.i18n.videoTooLarge || 'Video too large.' )
					: ( bparfwData.i18n.imageTooLarge || 'Image too large.' ),
					'error'
				);
				hasSizeError = true;
				return;
			}
			formData.append( 'media[]', file );
		} );
		if ( hasSizeError ) return;

		var pasteInput = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__paste-input' );
		if ( pasteInput && pasteInput.value ) {
			formData.append( 'paste_image', pasteInput.value );
		}

		fetch( bparfwData.restUrl + 'reviews', {
			method: 'POST',
			headers: {
				'X-WP-Nonce': bparfwData.nonce,
			},
			body: formData,
		} )
			.then( function ( res ) { return res.json(); } )
			.then( function ( result ) {
				if ( result.success ) {
					showFormMessage( block, result.message || bparfwData.i18n.submitSuccess, 'success' );
					form.reset();

					var starLabels = form.querySelectorAll( '.beplus-advanced-reviews-for-woocommerce__star-label' );
					starLabels.forEach( function ( label ) {
						label.classList.remove( 'beplus-advanced-reviews-for-woocommerce__star-label--active' );
					} );

					block._bparMediaFiles.length = 0;
					var mediaPreview = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview' );
					if ( mediaPreview ) {
						mediaPreview.style.display = 'none';
						mediaPreview.innerHTML = '';
					}

					var pasteInput = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__paste-input' );
					if ( pasteInput ) {
						pasteInput.value = '';
					}

					setTimeout( function () {
						var list = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__list' );
						if ( list && result.review ) {
							var noReviewsEl = list.querySelector( '.beplus-advanced-reviews-for-woocommerce__no-reviews' );
							if ( noReviewsEl ) {
								noReviewsEl.remove();
							}
							list.insertAdjacentHTML( 'afterbegin', buildReviewCard( result.review, block ) );
							if ( result.review.id ) {
								if ( ! block._bparExcludeIds ) block._bparExcludeIds = [];
								block._bparExcludeIds.push( result.review.id );
							}
						}

						var productId = parseInt( block.dataset.productId, 10 );
						if ( productId ) {
							var distUrl = new URL( bparfwData.restUrl + 'reviews/distribution' );
							distUrl.searchParams.set( 'product_id', productId );
							distUrl.searchParams.set( '_t', Date.now() );
							fetch( distUrl.toString(), { cache: 'no-store' } )
								.then( function ( res ) { return res.json(); } )
								.then( function ( data ) {
									var distArea = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__distribution' );
									if ( distArea ) {
										distArea.innerHTML = buildDistribution( data );
									}
								} )
								.catch( function () {} );
						}
					}, 500 );
				} else {
					showFormMessage( block, result.message || bparfwData.i18n.submitError, 'error' );
				}
			} )
			.catch( function () {
				showFormMessage( block, bparfwData.i18n.submitError, 'error' );
			} );
	}

	/**
	 * Render star rating HTML.
	 *
	 * @param {number} rating Rating value.
	 * @param {number} size   Optional size multiplier.
	 * @return {string} HTML string.
	 */
	var starSvgIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';

	function renderStars( rating, size ) {
		rating = Math.max( 1, Math.min( 5, rating || 0 ) );
		size = size || 1;
		var pxSize = 16 * size;
		var stars = '';
		for ( var i = 1; i <= 5; i++ ) {
			var filled = i <= rating ? ' beplus-advanced-reviews-for-woocommerce__star--filled' : ' beplus-advanced-reviews-for-woocommerce__star--empty';
			stars += '<span class="beplus-advanced-reviews-for-woocommerce__star' + filled + '" aria-hidden="true" style="width:' + size + 'em;height:' + size + 'em;"><svg width="' + pxSize + '" height="' + pxSize + '" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg></span>';
		}
		return '<span class="beplus-advanced-reviews-for-woocommerce__stars" aria-label="' + rating + ' out of 5 stars">' + stars + '</span>';
	}

	/**
	 * Build star distribution HTML.
	 *
	 * @param {Object} data Distribution data.
	 * @return {string} HTML string.
	 */
	function buildDistribution( data ) {
		if ( ! data || ! data.total ) {
			return '<p class="beplus-advanced-reviews-for-woocommerce__no-reviews">' + bparfwData.i18n.noReviews + '</p>';
		}

		var html = '<div class="beplus-advanced-reviews-for-woocommerce__distribution-header">';
		html += '<div class="beplus-advanced-reviews-for-woocommerce__average">';
		html += '<span class="beplus-advanced-reviews-for-woocommerce__average-value">' + ( data.average || 0 ) + '</span>';
		html += '<span class="beplus-advanced-reviews-for-woocommerce__average-stars">' + renderStars( Math.round( data.average || 0 ), 1.2 ) + '</span>';
		html += '<span class="beplus-advanced-reviews-for-woocommerce__total">' + data.total + ' ' + ( data.total === 1 ? 'review' : 'reviews' ) + '</span>';
		html += '</div>';

		html += '<div class="beplus-advanced-reviews-for-woocommerce__distribution-bars">';
		for ( var s = 5; s >= 1; s-- ) {
			var count = data.stars[ s.toString() ] || 0;
			var percent = data.total > 0 ? ( count / data.total * 100 ) : 0;
			html += '<div class="beplus-advanced-reviews-for-woocommerce__distribution-bar-row">';
			html += '<span class="beplus-advanced-reviews-for-woocommerce__distribution-bar-label">' + s + ' ' + starSvgIcon + '</span>';
			html += '<div class="beplus-advanced-reviews-for-woocommerce__distribution-bar-track">';
			html += '<div class="beplus-advanced-reviews-for-woocommerce__distribution-bar-fill" style="width:' + percent + '%" role="progressbar" aria-valuenow="' + count + '" aria-valuemin="0" aria-valuemax="' + data.total + '"></div>';
			html += '</div>';
			html += '<span class="beplus-advanced-reviews-for-woocommerce__distribution-bar-count">' + count + '</span>';
			html += '</div>';
		}
		html += '</div></div>';

		return html;
	}

	/**
	 * Build a single review card HTML (used by submit flow).
	 *
	 * @param {Object}      review Review object.
	 * @param {HTMLElement} block  Block container.
	 * @return {string} HTML string.
	 */
	function buildReviewCard( review, block ) {
		function escHtml( str ) {
			var div = document.createElement( 'div' );
			div.appendChild( document.createTextNode( str || '' ) );
			return div.innerHTML;
		}
		function escAttr( str ) {
			return ( str || '' ).replace( /"/g, '&quot;' ).replace( /'/g, '&#39;' );
		}

		var html = '<article class="beplus-advanced-reviews-for-woocommerce__review-card">';
		if ( block.dataset.showAvatar !== '0' ) {
			html += '<div class="beplus-advanced-reviews-for-woocommerce__review-avatar">';
			if ( review.avatar ) {
				html += '<img src="' + escAttr( review.avatar ) + '" alt="' + escAttr( review.author ) + '" width="40" height="40" loading="lazy">';
			} else {
				html += '<div class="beplus-advanced-reviews-for-woocommerce__review-avatar--fallback">' + escHtml( ( review.author || '' ).charAt(0).toUpperCase() ) + '</div>';
			}
			html += '</div>';
		}
		html += '<div class="beplus-advanced-reviews-for-woocommerce__review-body">';
		html += '<div class="beplus-advanced-reviews-for-woocommerce__review-header">';
		html += '<span class="beplus-advanced-reviews-for-woocommerce__review-author">' + escHtml( review.author ) + '</span>';
		html += '<span class="beplus-advanced-reviews-for-woocommerce__review-rating">' + renderStars( review.rating ) + '</span>';
		html += '</div>';
		html += '<div class="beplus-advanced-reviews-for-woocommerce__review-content">' + review.content + '</div>';

		if ( block.dataset.showImages !== '0' && review.has_images && review.images.length ) {
			var mediaData = review.images.map( function ( m ) {
				return { url: m.url, thumbnail: m.thumbnail || m.url, mime_type: m.mime_type || '' };
			} );
			html += '<div class="beplus-advanced-reviews-for-woocommerce__review-images" data-review-media="' + escAttr( JSON.stringify( mediaData ) ) + '">';
			review.images.forEach( function ( img, idx ) {
				if ( img.mime_type && img.mime_type.indexOf( 'video/' ) === 0 ) {
					html += '<button type="button" class="beplus-advanced-reviews-for-woocommerce__review-media-btn beplus-advanced-reviews-for-woocommerce__review-media-btn--video" data-media-index="' + idx + '" data-media-type="video" aria-label="' + escAttr( bparfwData.i18n.viewMedia || 'View media' ) + '">';
					html += '<video src="' + escAttr( img.url ) + '" width="80" height="80" class="beplus-advanced-reviews-for-woocommerce__review-video" muted preload="metadata"></video>';
					html += '</button>';
				} else {
					html += '<button type="button" class="beplus-advanced-reviews-for-woocommerce__review-media-btn" data-media-index="' + idx + '" data-media-type="image" aria-label="' + escAttr( bparfwData.i18n.viewMedia || 'View media' ) + '">';
					html += '<img src="' + escAttr( img.thumbnail ) + '" alt="" width="80" height="80" loading="lazy" class="beplus-advanced-reviews-for-woocommerce__review-image-thumb">';
					html += '</button>';
				}
			} );
			html += '</div>';
		}

		html += '<div class="beplus-advanced-reviews-for-woocommerce__review-date">' + escHtml( review.date_human ) + '</div>';
		html += '</div></article>';
		return html;
	}

	/**
	 * Initialize clipboard paste support.
	 *
	 * @param {HTMLElement} block The block container element.
	 */
	function initPasteSupport( block ) {
		if ( ! bparfwData.pasteEnabled ) return;

		var uploadZone = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__upload-zone' );
		if ( ! uploadZone ) return;

		var pasteInput = uploadZone.querySelector( '.beplus-advanced-reviews-for-woocommerce__paste-input' );

		uploadZone.addEventListener( 'paste', function ( e ) {
			var items = e.clipboardData && e.clipboardData.items;
			if ( ! items ) return;

			for ( var i = 0; i < items.length; i++ ) {
				if ( items[ i ].type.indexOf( 'image' ) === 0 ) {
					e.preventDefault();
					var blob = items[ i ].getAsFile();
					var maxSize = bparfwData.maxUploadSize || 2097152;
					if ( blob.size > maxSize ) {
						showFormMessage( block, bparfwData.i18n.imageTooLarge || 'Image too large.', 'error' );
						break;
					}
					var reader = new FileReader();
					reader.onload = function ( event ) {
						if ( pasteInput ) {
							pasteInput.value = event.target.result;
						}
						showPastePreview( block, event.target.result );
					};
					reader.readAsDataURL( blob );
					break;
				}
			}
		} );

		function showPastePreview( block, dataUrl ) {
			var form = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__submit-form' );
			if ( ! form ) return;

			var previewContainer = form.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview' );
			if ( ! previewContainer ) return;

			var existing = previewContainer.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview-item--paste' );
			if ( existing ) {
				existing.remove();
			}

			previewContainer.style.display = '';

			var item = document.createElement( 'div' );
			item.className = 'beplus-advanced-reviews-for-woocommerce__media-preview-item beplus-advanced-reviews-for-woocommerce__media-preview-item--paste';
			item.innerHTML =
				'<img src="' + dataUrl + '" alt="Pasted image" width="80" height="80" class="beplus-advanced-reviews-for-woocommerce__media-preview-img">' +
				'<span class="beplus-advanced-reviews-for-woocommerce__media-preview-name">Pasted image</span>' +
				'<button type="button" class="beplus-advanced-reviews-for-woocommerce__media-preview-remove" aria-label="Remove">&#10005;</button>';

			var removeBtn = item.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview-remove' );
			removeBtn.addEventListener( 'click', function () {
				item.remove();
				pasteInput.value = '';
				if ( ! previewContainer.querySelector( '.beplus-advanced-reviews-for-woocommerce__media-preview-item' ) ) {
					previewContainer.style.display = 'none';
				}
			} );

			previewContainer.appendChild( item );
		}
	}

	/**
	 * Initialize lightbox for review media (images + videos).
	 * Uses event delegation for performance, supports prev/next nav,
	 * keyboard (Esc/arrows), focus trap, counter display.
	 *
	 * @param {HTMLElement} block The block container element.
	 */
	function initLightbox( block ) {
		var listContainer = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__list' );
		if ( ! listContainer ) return;

		var lightbox = null;
		var currentMedia = [];
		var currentIndex = 0;
		var lastFocusedEl = null;
		var currentVideoEl = null;

		var LIGHTBOX_ID = 'bpar-lightbox';

		listContainer.addEventListener( 'click', function ( e ) {
			var mediaBtn = e.target.closest( '.beplus-advanced-reviews-for-woocommerce__review-media-btn' );
			if ( ! mediaBtn ) return;

			e.preventDefault();

			var imagesContainer = mediaBtn.closest( '.beplus-advanced-reviews-for-woocommerce__review-images' );
			if ( ! imagesContainer ) return;

			var rawMedia = imagesContainer.getAttribute( 'data-review-media' );
			if ( ! rawMedia ) return;

			try {
				currentMedia = JSON.parse( rawMedia );
			} catch ( err ) {
				return;
			}

			if ( ! currentMedia.length ) return;

			currentIndex = parseInt( mediaBtn.getAttribute( 'data-media-index' ), 10 ) || 0;
			if ( currentIndex < 0 ) currentIndex = 0;
			if ( currentIndex >= currentMedia.length ) currentIndex = currentMedia.length - 1;

			lastFocusedEl = mediaBtn;
			openLightbox();
		} );

		function openLightbox() {
			if ( lightbox ) return;

			lightbox = document.createElement( 'div' );
			lightbox.id = LIGHTBOX_ID;
			lightbox.className = 'beplus-advanced-reviews-for-woocommerce__lightbox';
			lightbox.setAttribute( 'role', 'dialog' );
			lightbox.setAttribute( 'aria-modal', 'true' );
			lightbox.setAttribute( 'aria-label', 'Media viewer' );

			var overlay = document.createElement( 'div' );
			overlay.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-overlay';

			var closeBtn = document.createElement( 'button' );
			closeBtn.type = 'button';
			closeBtn.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-close';
			closeBtn.setAttribute( 'aria-label', 'Close' );
			closeBtn.innerHTML = '&#10005;';
			closeBtn.addEventListener( 'click', closeLightbox );

			var content = document.createElement( 'div' );
			content.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-content';

			var prevBtn = null;
			var nextBtn = null;

			if ( currentMedia.length > 1 ) {
				prevBtn = document.createElement( 'button' );
				prevBtn.type = 'button';
				prevBtn.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-nav beplus-advanced-reviews-for-woocommerce__lightbox-prev';
				prevBtn.setAttribute( 'aria-label', 'Previous' );
				prevBtn.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>';
				prevBtn.addEventListener( 'click', function () { navigate( -1 ); } );

				nextBtn = document.createElement( 'button' );
				nextBtn.type = 'button';
				nextBtn.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-nav beplus-advanced-reviews-for-woocommerce__lightbox-next';
				nextBtn.setAttribute( 'aria-label', 'Next' );
				nextBtn.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
				nextBtn.addEventListener( 'click', function () { navigate( 1 ); } );
			}

			var counter = document.createElement( 'div' );
			counter.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-counter';
			counter.setAttribute( 'aria-live', 'polite' );

			lightbox.appendChild( overlay );
			lightbox.appendChild( closeBtn );
			lightbox.appendChild( content );
			if ( prevBtn ) lightbox.appendChild( prevBtn );
			if ( nextBtn ) lightbox.appendChild( nextBtn );
			lightbox.appendChild( counter );

			document.body.appendChild( lightbox );

			overlay.addEventListener( 'click', closeLightbox );

			document.addEventListener( 'keydown', onKeyDown );
			document.body.style.overflow = 'hidden';

			requestAnimationFrame( function () {
				lightbox.classList.add( 'beplus-advanced-reviews-for-woocommerce__lightbox--open' );
			} );

			renderCurrentMedia();
			trapFocus();
		}

		function closeLightbox() {
			if ( ! lightbox ) return;

			destroyVideo();

			document.removeEventListener( 'keydown', onKeyDown );
			document.body.style.overflow = '';

			lightbox.classList.remove( 'beplus-advanced-reviews-for-woocommerce__lightbox--open' );

			var onTransitionEnd = function () {
				if ( lightbox && lightbox.parentNode ) {
					lightbox.parentNode.removeChild( lightbox );
				}
				lightbox = null;
				currentMedia = [];
				currentIndex = 0;
				currentVideoEl = null;

				if ( lastFocusedEl ) {
					lastFocusedEl.focus();
					lastFocusedEl = null;
				}
			};

			if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
				onTransitionEnd();
			} else {
				lightbox.addEventListener( 'transitionend', onTransitionEnd, { once: true } );
				setTimeout( onTransitionEnd, 350 );
			}
		}

		function renderCurrentMedia() {
			if ( ! lightbox ) return;

			var content = lightbox.querySelector( '.beplus-advanced-reviews-for-woocommerce__lightbox-content' );
			var counter = lightbox.querySelector( '.beplus-advanced-reviews-for-woocommerce__lightbox-counter' );
			if ( ! content ) return;

			destroyVideo();

			var media = currentMedia[ currentIndex ];
			if ( ! media ) return;

			var isVideo = media.mime_type && media.mime_type.indexOf( 'video/' ) === 0;

			content.innerHTML = '';

			if ( isVideo ) {
				var video = document.createElement( 'video' );
				video.src = media.url;
				video.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-media beplus-advanced-reviews-for-woocommerce__lightbox-media--video';
				video.controls = true;
				video.setAttribute( 'playsinline', '' );
				video.style.width = 'min( 90vw, 1280px )';
				video.style.height = 'auto';
				content.appendChild( video );
				currentVideoEl = video;
			} else {
				var img = document.createElement( 'img' );
				img.src = media.url;
				img.className = 'beplus-advanced-reviews-for-woocommerce__lightbox-media';
				img.alt = '';
				content.appendChild( img );
			}

			if ( counter ) {
				counter.textContent = ( currentIndex + 1 ) + ' / ' + currentMedia.length;
			}

			updateNavVisibility();
		}

		function navigate( direction ) {
			if ( ! lightbox || ! currentMedia.length ) return;

			var newIndex = currentIndex + direction;
			if ( newIndex < 0 || newIndex >= currentMedia.length ) return;

			currentIndex = newIndex;
			renderCurrentMedia();
		}

		function updateNavVisibility() {
			var prevBtn = lightbox.querySelector( '.beplus-advanced-reviews-for-woocommerce__lightbox-prev' );
			var nextBtn = lightbox.querySelector( '.beplus-advanced-reviews-for-woocommerce__lightbox-next' );

			if ( prevBtn ) {
				prevBtn.style.visibility = currentIndex > 0 ? '' : 'hidden';
			}
			if ( nextBtn ) {
				nextBtn.style.visibility = currentIndex < currentMedia.length - 1 ? '' : 'hidden';
			}
		}

		function destroyVideo() {
			if ( currentVideoEl ) {
				currentVideoEl.pause();
				currentVideoEl.removeAttribute( 'src' );
				currentVideoEl.load();
				currentVideoEl = null;
			}
		}

		function onKeyDown( e ) {
			if ( e.key === 'Escape' || e.key === 'Esc' ) {
				e.preventDefault();
				closeLightbox();
				return;
			}

			if ( e.key === 'ArrowLeft' ) {
				e.preventDefault();
				navigate( -1 );
				return;
			}

			if ( e.key === 'ArrowRight' ) {
				e.preventDefault();
				navigate( 1 );
				return;
			}

			if ( e.key === 'Tab' ) {
				trapFocus( e );
			}
		}

		function trapFocus( e ) {
			if ( ! lightbox ) return;

			var focusable = lightbox.querySelectorAll(
				'button:not([disabled]), [tabindex]:not([tabindex="-1"])'
			);

			if ( ! focusable.length ) return;

			var first = focusable[ 0 ];
			var last = focusable[ focusable.length - 1 ];

			if ( e ) {
				if ( e.shiftKey && document.activeElement === first ) {
					e.preventDefault();
					last.focus();
				} else if ( ! e.shiftKey && document.activeElement === last ) {
					e.preventDefault();
					first.focus();
				}
				return;
			}

			first.focus();
		}
	}

	/**
	 * Show a message in the form area.
	 *
	 * @param {HTMLElement} block   Block container.
	 * @param {string}      message Message text.
	 * @param {string}      type    Message type ('success' or 'error').
	 */
	function showFormMessage( block, message, type ) {
		var formWrapper = block.querySelector( '.beplus-advanced-reviews-for-woocommerce__submit-form-wrapper' );
		if ( ! formWrapper ) return;

		var existing = formWrapper.querySelector( '.beplus-advanced-reviews-for-woocommerce__form-message' );
		if ( existing ) {
			existing.remove();
		}

		var msg = document.createElement( 'div' );
		msg.className = 'beplus-advanced-reviews-for-woocommerce__form-message beplus-advanced-reviews-for-woocommerce__form-message--' + type;
		msg.textContent = message;
		msg.setAttribute( 'role', 'alert' );
		formWrapper.insertBefore( msg, formWrapper.firstChild );

		setTimeout( function () {
			msg.remove();
		}, 5000 );
	}
} )();
